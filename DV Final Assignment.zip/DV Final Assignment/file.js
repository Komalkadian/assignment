var data = d3.csv("country_wise_latest.csv", function(data) { return {Confirmed, Deaths};})

        var height = 100;
        var width = 100;
        
        var y = d3.scaleLinear().domain([0, 2500]).range([height,0]);
        var x = d3.scaleBand().domain([100,500,1000,2500]).range([width, 0]);

        var yAxis =d3.axisLeft(y);
        var xAxis = d3.axisBottom(x);

        var svg =d3.select('body').append('svg').attr('height', '100%').attr('width', '100%');

        var chartGroup = svg.append('g').attr('transform','translate(50,50)');
        var line = d3.line().x(function(d) {return x(d.Confirmed);}).y(function(d) {return x(d.Deaths);});

        chartGroup.append('path').attr('d', line(data));

    