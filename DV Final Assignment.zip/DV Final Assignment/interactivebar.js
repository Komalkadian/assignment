function main() {
    
    var svg = d3.select("svg"),
        margin = {top: 30, right: 30, bottom: 70, left: 60},
        width = svg.attr("width") - margin.left - margin.right,
        height = svg.attr("height") - margin.top - margin.bottom;
        
        const data1 = [
            {group: "Americas", value: 4},
            {group: "Europe", value: 16},
            {group: "South-East Asia", value: 8},
            {group: "Eastern Mediterranean", value: 8},
            {group: "Africa", value: 8},
            {group: "Western Pacific", value: 8}
         ];
         
         const data2 = [
            {group: "Americas", value: 15},
            {group: "Europe", value: 14},
            {group: "South-East Asia", value: 18},
            {group: "Eastern Mediterranean", value: 8},
            {group: "Africa", value: 10},
            {group: "Western Pacific", value: 8}
         ];

            svg.append("g").select("#my_dataviz")
            .append("svg")
              .attr("width", width + margin.left + margin.right)
              .attr("height", height + margin.top + margin.bottom)
            .append("g")
              .attr("transform", `translate(${margin.left},${margin.top})`);
 
              // Parse the Data
d3.csv("country_wise_latest.csv").then( function(data) {

    // X axis
    const x = d3.scaleBand()
      .range([ 0, width ])
      .domain(data1.map(d => d.group))
      .padding(0.2);
    svg.append("g")
      .attr("transform", `translate(0, ${height})`)
      .call(d3.axisBottom(x))
      .selectAll("text")
        .attr("transform", "translate(-10,0)rotate(-45)")
        .style("text-anchor", "end");
    
    // Add Y axis
    const y = d3.scaleLinear()
      .domain([0, 20000])
      .range([ height, 0]);
    svg.append("g").attr("class", "myYaxis")
      .call(d3.axisLeft(y).tickFormat(function(d){ return d;}).ticks(10));
    
    
    })
}

function update(data) {

    var u = svg.selectAll("rect")
      .data(data)
  
    u
      .join("rect")
      .transition()
      .duration(1000)
        .attr("x", d => x(d.group))
        .attr("y", d => y(d.value))
        .attr("width", x.bandwidth())
        .attr("height", d => height - y(d.value))
        .attr("fill", "#69b3a2")
  }
  
  // Initialize the plot with the first dataset
  update(data1)