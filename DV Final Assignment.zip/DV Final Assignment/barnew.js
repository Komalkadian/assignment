function main() {
  var svg = d3.select("svg"),
   margin = {top: 10, right: 30, bottom: 30, left: 40},
    width = svg.attr("width") - margin.left - margin.right,
    height = svg.attr("height") - margin.top - margin.bottom;


    
    svg.append("g")
       .attr("transform", "translate("+ 100 +","+ 100 +")")
      
  
            d3.csv("country_wise_latest.csv").then(function(data){
  
              var x = d3.scaleLinear()
              //.domain([0, d3.max(data, (d)=> {return Math.max(d.Deaths);})+ 20000])
              .domain([0, 350000])
              .range([ 0, width]);
    
    
              svg.append("g")
              .attr("transform", "translate(0," + height + ")")
              .call(d3.axisBottom(x))
              .selectAll("text")
                .attr("transform", "translate(-10,0)rotate(-45)")
                .style("text-anchor", "end");
    
                svg.append("text")
                .attr("class", "x label")
                .attr("text-anchor", "end")
                .attr("x", width/4)
                .attr("y", height + 140)
                .text("Number of Deaths");

                var y = d3.scaleBand()
                          .range([ height, 0 ])
                          .domain(data.map(function(d) { return d.Region; }))
                          .padding(0.4);

                          svg.append("g")
    .call(d3.axisLeft(y));

    svg.append("text")
    .attr("class", "y label")
    .attr("text-anchor", "end")
    .attr("y", 10)
    .attr("dy", ".75em")
    .attr("transform", "rotate(-90)")
    .text("Countries");


      svg.selectAll(".bar")
    .data(data)
    .enter()
    .append("rect")
    .attr("x", x(0) )
    .attr("y", function(d) { return y(d.Region); })
    .attr("width", function(d) { return x(d.TotalDeath); })
    .attr("height", y.bandwidth() )
    .attr("fill", "#1a9cd9")


  });

}